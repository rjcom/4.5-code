﻿Public Class Listing03_05
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Response.Write("This is the Page_Load event")
    End Sub

End Class