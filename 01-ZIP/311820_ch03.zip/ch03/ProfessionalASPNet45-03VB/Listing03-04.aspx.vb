﻿Public Class Listing03_04
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub VerifyDataButtonClick(ByVal sender As Object, ByVal e As System.EventArgs)
        'Verify Data
    End Sub

End Class