﻿Public Class Calculator
    Public Function Add(a As Integer, b As Integer) As Integer
        Return (a + b)
    End Function
    Public Function Subtract(a As Integer, b As Integer) As Integer
        Return (a - b)
    End Function
End Class