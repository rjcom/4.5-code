﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Widgets
{
    public class FooBarWidget
    {
        public void Test()
        {
            //var x = new System.IO.File;
        }
    }
}