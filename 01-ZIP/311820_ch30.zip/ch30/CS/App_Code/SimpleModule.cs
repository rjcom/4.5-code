﻿using System;
using System.Web;

public class SimpleModule : IHttpModule
{

    public void Dispose()
    {
        throw new NotImplementedException();
    }

    public void Init(HttpApplication context)
    {
        throw new NotImplementedException();
    }
}
