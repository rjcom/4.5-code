﻿Public Class ProductsController
    Inherits System.Web.Mvc.Controller

    'Function Display() As ActionResult
    '    Return View()
    'End Function

    Function Display(id As Integer?) As ActionResult
        Return View()
    End Function

End Class
