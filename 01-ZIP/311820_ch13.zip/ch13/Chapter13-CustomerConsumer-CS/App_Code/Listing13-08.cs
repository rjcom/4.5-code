﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Listing13_08
/// </summary>
public class Listing13_08
{
    public string HelloWorld()
    {
        return "Hello";
    }
    public string HelloWorld(string FirstName)
    {
        return "Hello " + FirstName;
    }
}