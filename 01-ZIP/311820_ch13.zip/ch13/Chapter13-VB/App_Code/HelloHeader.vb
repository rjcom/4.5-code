﻿Imports Microsoft.VisualBasic

Public Class HelloHeader
    Inherits System.Web.Services.Protocols.SoapHeader
    Public Username As String
    Public Password As String
End Class