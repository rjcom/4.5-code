﻿function helloWorld(firstName) {
    // Declare variables
    var message = "Hello, " + firstName;

    // Display an alert message
    alert(message);
}