﻿// Default code generation is disabled for model 'C:\Projects\Chapter11\AspnetEntityFx\AspnetEntityFx\EmployeeDM.edmx'. 
// To enable default code generation, change the value of the 'Code Generation Strategy' designer
// property to an alternate value. This property is available in the Properties Window when the model is
// open in the designer.