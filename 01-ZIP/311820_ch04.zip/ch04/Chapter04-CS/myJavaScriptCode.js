﻿function AlertHello() {
    alert('Hello ASP.NET');
}