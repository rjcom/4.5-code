﻿Public Class Message
    Inherits System.Web.UI.WebControls.Panel
    Implements System.Web.UI.INamingContainer

    Public Property Name() As String
    Public Property Text() As String
End Class