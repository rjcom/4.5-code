﻿// RestClientMode.cs
//

using System;

namespace DynamicRest {

    public enum RestClientMode {

        Json,

        Xml
    }
}
